import { SwalState } from './state';
export declare const openModal: () => void;
export declare const onAction: (namespace?: string) => void;
export declare const getState: () => SwalState;
export declare const stopLoading: () => void;
