export declare const contentMarkup: string;
